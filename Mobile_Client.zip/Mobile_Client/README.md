## Group Project @KCL semester 2019 Spring 
### The Functions Of Mobile Client (v1) 
1. Sign Up
2. Login
3. Change Password
4. Forgot Password
5. Upload File
6. Download File
7. Delete File
8. Show File List
9. Sync File with Desktop

### How to Run Our App
1. Download the whole file from our repo
2. Using Android Studio to open our Mobile Client File
3. Install a simulator Which has API 25 above and  Resolution is 1440 X 2560: 560dpi
4. Run the Mobile Client File

